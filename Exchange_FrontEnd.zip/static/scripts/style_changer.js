function toggleStyle(){
	var curStyle = document.getElementById('pagestyle').getAttribute('href')
	var newStyle = (curStyle == "/styles/style_light.css" ? "/styles/style_dark.css" : "/styles/style_light.css")
	document.getElementById('pagestyle').setAttribute('href', newStyle);
	document.cookie = "GNTLCOUKHomestyle=" + (newStyle == "/styles/style_light.css" ? "light" : "dark") + "," + " expires=Sat, 31 Dec 2050 12:00:00 UTC";
	}

function isLightStyleSelected() {
	return document.cookie.match(/GNTLCOUKHomestyle=light/i) != null
}

function setStyleFromCookie() {
	var newStyle = (isLightStyleSelected() ? "/styles/style_light.css" : "/styles/style_dark.css")
	document.getElementById('pagestyle').setAttribute('href', newStyle);
}

(function() {
 	setStyleFromCookie()
})();